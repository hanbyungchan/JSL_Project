package common;

import javax.servlet.http.HttpServletRequest;

public interface CommonExecute {
	public void execute(HttpServletRequest request);
}