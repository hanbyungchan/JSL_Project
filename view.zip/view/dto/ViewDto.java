package dto;

public class ViewDto {
	private String s_page_no,s_game_code, g_grade,
	s_game_name, s_info_txt, s_date, s_sale,
	s_spec_1, s_spec_2, s_spec_3, s_spec_4, s_spec_5,
	s_img_main,
	s_img_1,s_img_2,s_img_3,s_icon,
	s_video_1, s_video_2, s_video_3, g_price;
	private double g_sale_price;
	
	public ViewDto() {
		super();
	}
	
	public String getG_grade() {
		return g_grade;
	}
	public void setG_grade(String g_grade) {
		this.g_grade = g_grade;
	}
	public String getS_page_no() {
		return s_page_no;
	}
	public void setS_page_no(String s_page_no) {
		this.s_page_no = s_page_no;
	}
	public String getS_game_code() {
		return s_game_code;
	}
	public void setS_game_code(String s_game_code) {
		this.s_game_code = s_game_code;
	}
	public String getS_game_name() {
		return s_game_name;
	}
	public void setS_game_name(String s_game_name) {
		this.s_game_name = s_game_name;
	}
	public String getS_info_txt() {
		return s_info_txt;
	}
	public void setS_info_txt(String s_info_txt) {
		this.s_info_txt = s_info_txt;
	}
	public String getS_date() {
		return s_date;
	}
	public void setS_date(String s_date) {
		this.s_date = s_date;
	}
	public String getS_sale() {
		return s_sale;
	}
	public void setS_sale(String s_sale) {
		this.s_sale = s_sale;
	}
	public String getS_spec_1() {
		return s_spec_1;
	}
	public void setS_spec_1(String s_spec_1) {
		this.s_spec_1 = s_spec_1;
	}
	public String getS_spec_2() {
		return s_spec_2;
	}
	public void setS_spec_2(String s_spec_2) {
		this.s_spec_2 = s_spec_2;
	}
	public String getS_spec_3() {
		return s_spec_3;
	}
	public void setS_spec_3(String s_spec_3) {
		this.s_spec_3 = s_spec_3;
	}
	public String getS_spec_4() {
		return s_spec_4;
	}
	public void setS_spec_4(String s_spec_4) {
		this.s_spec_4 = s_spec_4;
	}
	public String getS_spec_5() {
		return s_spec_5;
	}
	public void setS_spec_5(String s_spec_5) {
		this.s_spec_5 = s_spec_5;
	}
	public String getS_img_main() {
		return s_img_main;
	}
	public void setS_img_main(String s_img_main) {
		this.s_img_main = s_img_main;
	}
	public String getS_img_1() {
		return s_img_1;
	}
	public void setS_img_1(String s_img_1) {
		this.s_img_1 = s_img_1;
	}
	public String getS_img_2() {
		return s_img_2;
	}
	public void setS_img_2(String s_img_2) {
		this.s_img_2 = s_img_2;
	}
	public String getS_img_3() {
		return s_img_3;
	}
	public void setS_img_3(String s_img_3) {
		this.s_img_3 = s_img_3;
	}
	public String getS_icon() {
		return s_icon;
	}
	public void setS_icon(String s_icon) {
		this.s_icon = s_icon;
	}
	public String getS_video_1() {
		return s_video_1;
	}
	public void setS_video_1(String s_video_1) {
		this.s_video_1 = s_video_1;
	}
	public String getS_video_2() {
		return s_video_2;
	}
	public void setS_video_2(String s_video_2) {
		this.s_video_2 = s_video_2;
	}
	public String getS_video_3() {
		return s_video_3;
	}
	public void setS_video_3(String s_video_3) {
		this.s_video_3 = s_video_3;
	}
	public String getG_price() {
		return g_price;
	}
	public void setG_price(String g_price) {
		this.g_price = g_price;
	}
	public double getG_sale_price() {
		return g_sale_price;
	}
	public void setG_sale_price(double g_sale_price) {
		this.g_sale_price = g_sale_price;
	}
	
	
	
	
	
}
